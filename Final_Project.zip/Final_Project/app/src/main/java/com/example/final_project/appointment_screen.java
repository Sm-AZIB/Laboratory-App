package com.example.final_project;


import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class appointment_screen extends AppCompatActivity {

    EditText input_name;
    EditText input_age;

    Spinner spinner;
    Button submitButton;
    TextView selectedOptionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_appointment_screen);  // Ensure this layout file exists

        // Initialize views
        input_name = findViewById(R.id.name_input);
        input_age = findViewById(R.id.age_input);

        spinner = findViewById(R.id.spinner);
        submitButton = findViewById(R.id.submitButton);
        selectedOptionText = findViewById(R.id.selectedOptionText);

        // Array of options for the Spinner
        String[] options = {"Blood Test", "Echocardiogram", "MRI", "Ultrasound"};

        // Create an ArrayAdapter to populate the Spinner with options
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Set the adapter to the Spinner
        spinner.setAdapter(adapter);

        // Set an OnClickListener for the submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textFromName = input_name.getText().toString();
                input_name.setText("");
                String textFromAge = input_age.getText().toString();
                input_age.setText("");
                // Get the selected option from the Spinner
                String selectedOption = spinner.getSelectedItem().toString();

                // Conditional check using if-else statements to display a specific message based on the selection
                String message = "";

                if (selectedOption.equals("Blood Test")) {
                    message = "Your Appointment For Blood Test is Confirmed!";
                } else if (selectedOption.equals("Echocardiogram")) {
                    message = "Your Appointment For Echo Test is Confirmed";
                } else if (selectedOption.equals("MRI")) {
                    message = "Your Appointment For MRI is Confirmed";
                } else if (selectedOption.equals("Ultrasound")) {
                    message = "Your Appointment For Ultrasound is Confirmed";
                } else {
                    message = "Please select an option.";
                }

                // Display the message in the TextView
                selectedOptionText.setText(message);

                // Optionally, show a Toast with the selected option's message
                Toast.makeText(appointment_screen.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
